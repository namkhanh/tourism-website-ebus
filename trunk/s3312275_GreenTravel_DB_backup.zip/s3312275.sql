-- phpMyAdmin SQL Dump
-- version 2.6.2-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 06, 2012 at 02:03 PM
-- Server version: 5.0.77
-- PHP Version: 5.3.3
-- 
-- Database: `s3312275`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `customer`
-- 

CREATE TABLE `customer` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(40) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(40) NOT NULL,
  `street` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `nationality` varchar(40) NOT NULL,
  `activation` tinytext NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY  (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `customer`
-- 

INSERT INTO `customer` VALUES ('anhdenday', 'lalala', 'Long', 'Tran', '1991-09-14', 'longhtran91@gmail.com', '467 CMT8', 'Binh Duong', 'Vietnam', '', 0);
INSERT INTO `customer` VALUES ('ronthekid', 'lalala', 'Duy', 'Le', '1991-03-30', 'ronthekid1503@gmail.com', '51 Xa Lo Binh Duong', 'Binh Duong', 'Vietnam', '', 0);
INSERT INTO `customer` VALUES ('dat.xuong', 'lalala', 'Dat', 'Duong', '1991-06-11', 'xuongdat@gmail.com', '576 Nguyen Trai', 'HCMC', 'Vietnam', '', 0);
INSERT INTO `customer` VALUES ('inte', '2435', 'Rupan Kanti', 'Das', '1970-04-14', 'rupan.das@rmit.edu.vn', '702 Nguyen Van Linh', 'HCMC', 'Bangladesh', '', 0);
INSERT INTO `customer` VALUES ('longhtran91', 'n0p@ssw0rd', 'Tran', 'Long', '1991-09-14', 'longhtran91@gmail.com', '467 CMT8', 'Binh Duong', '244', '2e105d2cc632e75d0f5ad65b44680ba9', 1);
INSERT INTO `customer` VALUES ('1231231231', '123456', 'tran', 'long', '1970-01-01', 'longhtran91@gmail.com', 'dsada', 'dsada', '244', '55a844dab2b1ab845ecc93ebbe8e222b', 0);
INSERT INTO `customer` VALUES ('nicklast', 'vanson', 'nguyen', 'son', '1991-03-11', 'nicklast91@ymail.com', 'cong hoa', 'ho chi minh', '244', '8794c92b494ac97b38ecd32c8f48d3e4', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `ebook`
-- 

CREATE TABLE `ebook` (
  `ebookID` int(11) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `author` varchar(40) NOT NULL,
  `price` double NOT NULL,
  `description` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `download` tinytext NOT NULL,
  PRIMARY KEY  (`ebookID`),
  FULLTEXT KEY `url` (`img`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `ebook`
-- 

INSERT INTO `ebook` VALUES (1, 'Walking The London Loop', 'Rony', 20000, 'Walking The London Loop is one of the great travel ebooks. Don''t miss it', 'ebook/london.jpg', 'ebook/walking_the_london_loop.epub');
INSERT INTO `ebook` VALUES (2, 'Travels In The Gambia', 'Hoang Long', 40000, 'Gambia, wide open walls!', 'ebook/gambia.jpg', 'ebook/travels_in_the_gambia.epub');
INSERT INTO `ebook` VALUES (8, 'Da Lat Travel', 'Xuong Dat', 35000, 'Dalat is a city of Lam Dong province, located on Lam Vien Plateau, Central Highlands, Vietnam. Since ancient times, this land area which is the residence of the Creek residents, the Chil and Coho ethnic Sre. Late 19th century, when looking for a place to build health resort for the French in Indochina, the Governor has decided Doumer Paul Lam Vien Plateau at the request of Dr. Alexandre Yersin, who explore to this place in 1893.', 'uploads/dalat83.jpg?d=1336185911944', 'ebook/Da Lat.pdf');
INSERT INTO `ebook` VALUES (10, 'Hoi An Travel', 'UknowBetter', 55000, 'Hoi An is a provincial city, was founded January 29, 2008 by Decree No. 10/2008/ND-CP of the Government of Socialist Republic of Vietnam. Hoi An is now recognized as grade III, directly under the province of Quang Nam.', 'uploads/hoi an.jpg?d=1336187015081', 'ebook/Hoi An.pdf');
INSERT INTO `ebook` VALUES (11, 'Nha Trang - Beaches welcome you', 'Wontiam', 60000, 'Nha Trang is a coastal city and a center of political, economic, cultural, scientific and tourism in the province of Khanh Hoa, Vietnam. Before becoming the land of Vietnam, Nha Trang belongs Champa. The ruins of the Cham people remain in parts of Nha Trang. Nha Trang is Vietnam Prime Minister recognized as grade 1 on April 22, 2009. This is one of eight urban under class 1 provinces of Vietnam.', 'uploads/nha trang.jpg?d=1336187184909', 'ebook/Nha Trang.pdf');
INSERT INTO `ebook` VALUES (9, 'Da Nang Travel', 'Rony', 77000, 'Danang is the economic center and is one of the cultural centers, education, science and technology of the large central area - Highlands, is the 5th most populous city of Vietnam, after Ho Chi Minh City, Hanoi, Hai Phong and Can Tho. The city lies along the southern central coast. Danang is one of three urban centers of a centrally in Vietnam (along with Hai Phong and Can Tho).', 'uploads/da nang.jpg?d=1336186813461', 'ebook/Da Nang.pdf');

-- --------------------------------------------------------

-- 
-- Table structure for table `ebook_shopping`
-- 

CREATE TABLE `ebook_shopping` (
  `ebook_shopping_id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `username` varchar(255) NOT NULL,
  `ebookID` varchar(255) NOT NULL,
  PRIMARY KEY  (`ebook_shopping_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `ebook_shopping`
-- 

INSERT INTO `ebook_shopping` VALUES (1, '2012-04-23', 'inte', '1');
INSERT INTO `ebook_shopping` VALUES (2, '2012-04-22', 'ronthekid', '2');
INSERT INTO `ebook_shopping` VALUES (6, '2012-05-05', 'inte', '2');
INSERT INTO `ebook_shopping` VALUES (7, '2012-05-05', 'ronthekid', '11');

-- --------------------------------------------------------

-- 
-- Table structure for table `event`
-- 

CREATE TABLE `event` (
  `eventID` varchar(8) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY  (`eventID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `event`
-- 

INSERT INTO `event` VALUES ('1', 'Ha Noi - The Capital', 'Hanoi is the capital, and is the leading city of Vietnam on the natural area and second largest urban area after Ho Chi Minh City, it also ranks second in population with 6,913,161 people. Located between the rich Red River delta, where it soon became a center of political and religious right from the beginning of Vietnam''s history. In 1010, Ly Cong Uan, the first king of the Ly, decided to build a new capital in this area with the name Thang Long. During the period of the reign of Ly, Tran, Le, Mac, Thang Long is a marketplace, cultural centers, education of both the north. When the Tay Son and Nguyen took over the reign, the capital was moved to Hue and named Thang Long Hanoi began in 1831 under King Minh Mang. In 1902, Hanoi became the capital of the Indochinese Federation and the French-built and re-planning. Through two wars, Hanoi is the capital of North Vietnam and unified the country and in this role to this day.', '2012-05-13', 'images/hot-tour/1.jpg');
INSERT INTO `event` VALUES ('2', 'Hoi An - Ancient City', 'Hoi An (About this sound listen), or rarely Faifo, is a city of Vietnam, on the coast of the South China Sea in the South Central Coast of Vietnam. It is located in Quang Nam province and is home to approximately 120,000 inhabitants. It is as a World Heritage Site recognized by UNESCO.Hoi An Ancient Town is an exceptionally well-preserved example of a South-East Asian trading port dating from the 15th to the 19th century. Its buildings and its street plan reflect the influences, both indigenous and Foreign, that have combined to Produce this unique heritage site.\r\n\r\nThe city possessed the largest harbor in Southeast Asia in the 1st century and was known as Lam Ap Pho (Champa City). Between the Seventh and 10th centuries, the Cham (People of Champa) controlled the spice trade and with this Strategic came Tremendous wealth. The former harbor town of the Cham at the Estuary of the Thu Bon River was an important ''Vietnamese trading center in the 16th and 17th centuries, where Chinese from various Provinces as well as Japanese, Dutch and Indians settled. During this period of the China trade, the town was Called Hai Pho (Seaside Town) in Vietnamese. Originally, The Divided City was a town with the Japanese settlement across the "Japanese Bridge" (16th-17th century). The bridge (Bridge Pagoda) is a unique structure built by the Japanese Covered, the only known Covered bridge with a Buddhist pagoda attached to one side.', '2012-05-26', 'images/hot-tour/2.jpg');
INSERT INTO `event` VALUES ('3', 'Four seasonal Sapa', 'Located in the northwest of the country, Sapa is a mountainous district of Lao Cai province, a land of modest, quietly but hides many wonders of the natural scene. Natural beauty of Sapa is combined with human creativity with the topography of the mountains, green forests, the paintings are arranged in a harmonious composition makes a lot of landscape areas best romantic appeal.\r\n\r\nImmersed in the clouds floating in Sapa as a magical city in mist, paint a charming picture painted glass. Here, things are invaluable resources that is cool and fresh air, nuanced diversity. Located at an average altitude of 1500m - 1800m, Sa Pa, the climate more or less the nuances of tropical origin, with average temperatures 15-18 C. From May to August is the wet season.\r\n\r\nSa Pa this name from the Mandarin. Mandarin called Sa - Pa, "Sa" means sand, "Pa" is the beach. Places of "sand" on the right side of this bridge 32 km from Lao Cai to Sapa. No ancient town of Sa Pa, inhabitants of this land is for the "sand" it. Therefore, local people who also say "Sa Pa shopping."\r\n\r\nFrom the word "Sa Pa," Westerners pronounce no sign, so the Sa Pa and they have two letters written in French is "Cha Pa" and a very long time we were called "Cha Pa" within the meaning of words in Vietnamese.\r\n\r\nBut today the town of Sa Pa, before there is a circuit module to the turbid water red, so the locals called "Hung Ho", "Hung" is red, "Ho" is galaxy, the springs and streams of red.\r\n\r\nSa Pa is a high peak Phan Si Pang 3.143m on Hoang Lien Son range. Call the Hoang Lien Son Mountains by this single tree Hoang Lien, a precious medicinal herbs, rare. Also Hoang Lien also "mine" of precious wood species like pine oil, of how birds and animals, such as partridges, bears, monkeys, chamois and the thousands of drugs. National forests of Hoang Lien Son has 136 species of birds, 56 mammals, 553 species of insects. There are 37 mammal species recorded in the "Red Book of Vietnam. Hoang Lien Son forests have 864 species of plants, including 173 species of medicinal plants.', '2012-05-23', 'images/hot-tour/3.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `occurance`
-- 

CREATE TABLE `occurance` (
  `dayName` varchar(255) NOT NULL,
  PRIMARY KEY  (`dayName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `occurance`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `region`
-- 

CREATE TABLE `region` (
  `regionID` int(11) NOT NULL auto_increment,
  `r_name` varchar(255) NOT NULL,
  PRIMARY KEY  (`regionID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `region`
-- 

INSERT INTO `region` VALUES (1, 'North Vietnam');
INSERT INTO `region` VALUES (2, 'Middle Vietnam');
INSERT INTO `region` VALUES (3, 'South Vietnam');

-- --------------------------------------------------------

-- 
-- Table structure for table `review`
-- 

CREATE TABLE `review` (
  `reviewID` int(11) NOT NULL auto_increment,
  `title` tinytext NOT NULL,
  `comment` tinytext NOT NULL,
  `rate` int(11) NOT NULL,
  `r_date` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `tourID` int(11) NOT NULL,
  `tour_booking_id` varchar(11) NOT NULL,
  PRIMARY KEY  (`reviewID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `review`
-- 

INSERT INTO `review` VALUES (3, 'The best tour I ever had', 'This is great service', 5, '05-05-2012 08:05:55', 'inte', 1, '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `tour`
-- 

CREATE TABLE `tour` (
  `tourID` int(11) NOT NULL auto_increment,
  `t_name` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `price` double NOT NULL,
  `description` text NOT NULL,
  `destination` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `regionID` varchar(255) NOT NULL,
  PRIMARY KEY  (`tourID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `tour`
-- 

INSERT INTO `tour` VALUES (1, 'Ha Noi - Ha Long Bay - Sapa Tour', '5 Days, 4 Nights', 11000000, 'Come to Sapa, you can enjoy the beautiful falling snow, a charm in a place was dubbed "Princess in the Clouds", a place where life is simple and friendly. Visited the capital, visitors will enjoy the sweetest taste of special ice cream bars Trang Tien.<br /> <br />\r\nThis tour also takes visitors to Ha Long Bay - one of the seven natural wonders of the world (according to UNESCO). Ha Long Bay becomes more miraculous appearance by mountains, caves and river in the mist like floating.<br /><br />\r\n\r\n', 'Ha Noi - Ha Long - Sapa', 'images/tour/ha_long.jpg', '1');
INSERT INTO `tour` VALUES (2, 'Da Lat Travel', '5 days, 4 nights', 2500000, '<b>Day 1: Hanoi / Ho Chi Minh city - Da Lat city</b><br />\r\nAt night, you walk around Da Lat night, enjoy the night market delicacies in the underworld, coffee flavor in the restaurant and gracefully mountain town, sightseeing Ho Xuan Huong, overnight in Dalat.<br /><br />\r\n \r\n<b>Day 2: Da Lat City Tour (Breakfast, Lunch, Dinner)</b><br />\r\nIn the morning, you walk a population enjoy most scenic highland forest operators who ... Ankroet, Yellow Creek Lake, Lake Dankia, Golden Valley. Continue to drive to the salad, trafficking of people at the foot of the mountain Lat Loc Langbiang, the way you admire outskirts of Da Lat with all sorts of garden planted crops. You climb the mountain, conquering Langbiang; from mountain to admire the entire city of Dalat romantic, mysterious fog.<br />\r\nIn the afternoon, you visit a church Domain-de Marie, visit Bao Dai palaces, gardens Bich.<br />\r\nIn the evening, you attend the campfire, drinking wine, arts gongs, cultural exchanges with the Central Highlands, overnight in Dalat.<br /><br />\r\n \r\n<b>Day 3: Da Lat City Tour (Breakfast, Lunch, Dinner)</b><br />\r\nIn the morning, go by boat to visit Tuyen Lam lake, Truc Lam Zen Monastery, take the cable car through Robin Hill, a scenic pine forest, Tuyen Lam lake and mountains from above Phoenix.<br />\r\nIn the afternoon, you visit Mong Mo Hill or Valley of Love, see the embroidery in Dalat Historical House. Visit Dalat market customers to buy special, four-wheel ride horses neck walking around Ho Xuan Huong.<br />\r\nAt night, the customer''s own program, overnight in Dalat.<br /><br />\r\n \r\n<b>Day 4: Da Lat - Hanoi / Ho Chi Minh City (Breakfast)</b><br />\r\nIn the morning, you are free, guide traffic ticket company and guide the procedures, then you are the Lien Khuong airport. Bye bye you.', 'Da Lat', 'images/tour/da_lat.jpg', '2');
INSERT INTO `tour` VALUES (4, 'Ha Long with Poseidon Sail', '3 Days, 2 Nights', 3100000, 'Ha Long has become one of the most favorite place of visitors (domestic and foreign also) around the world. This place is well-known as one of the seven natural wonders of the world. <br /><br />\r\n\r\nThe specialty of this tour is visitors travel in <b>Poseidon Sail</b>. This yacht is totally made by wood with Vietnam contemporary architecture. This includes 08 bedrooms, spacious balcony, a luxury restaurant, a bar and Spa also. With our trained-professional staffs, Green Travel will bring visitors to an exciting tour with unforgettable memories.', 'Ha Long Bay - Cat Ba island', 'images/tour/poseidon_sail.jpg', '1');
INSERT INTO `tour` VALUES (7, 'Phu Yen Travel', '3 days, 2 nights', 5000000, '<div class="">Day 1:</div>\r\n<b>15h30:</b> Car and Travel Guide Thuan Thao welcome you at Tuy Hoa airport, take the 5-star hotel room CenDeluxe. Enjoy free coffee, watching the sunset and panoramic Tuy Hoa city in the 17th floor Sky Lounge restaurant of the hotel (coffee costs excluded),\r\n<br />\r\n<b>17h00:</b> Have dinner at restaurant Ba Mien.\r\n<br />\r\n<b>18h30:</b> You participate in the opening of the festival''s 17th Vietnam Sao Mai theater under Thuan Thao Corporation; CenDeluxe Overnight at hotel.\r\n<br /><br />\r\n<div class="">Day 2:</div>\r\n<b>07h00:</b> Have breakfast at hotel.\r\n<br />\r\n<b>07h30:</b> Pick and Thuan Thao Travel guides take you to visit Wat Thanh Luong good things for peace, listen to the story about the encounter between God predestined to Bodhisattva Avalokitesvara your wood over 200 years old. Continue you tour program Ganh Ganh MD has a width of about 50 meters and stretching over 200 meters, there are upright stones in each column, associated with a cross section close fitting hexagonal or round like a discs stacked so called Ganh MD. Back to the hotel, have lunch and rest.\r\n<br />\r\n<b>14h30:</b> Visit the Ecology Center Thuan Thao, Former Land yachts visiting the land of the past to experience the mysteries of the earth through the creation period, the strangeness of the native tribes, volcano , three-headed snake, tree cannibalism and many other pleasant surprise, joined other entertainment programs organized by the Centre. Thuan Thao swimming at Golden beach with sea water pool on a 800 m2 area, watching the sunset over the sea in the context of lyrical, romantic. Have dinner at the Seafood restaurant. Overnight at hotel CenDeluxe.\r\n<br /><br />\r\n<div class="">Day 3:</div>\r\n<b>07h00:</b> Have breakfast at the hotel.\r\n<br />\r\n<b>07h30:</b> Pick up your visitors Resort Hoang Long, Vung Ro Bay, where the victories of the associated train without number, point to the Ho Chi Minh road at sea, visiting Mui Dien Lighthouse, photograph at the easternmost point milestone Nation, Bai Mon panoramic sea from a height of 110 meters above the water surface bien.Tro of Tuy Hoa city center, have lunch and rest.\r\n<br />\r\n<b>13h30:</b> Have procedures in office, shopping for souvenirs in Thuan Thanh Supermarket; 15:00: car and guide will take you to the airport Tuy Hoa. You broke up, ending the tour full of fun.', 'Phu Yen', 'uploads/phuyen.jpg', '2');
INSERT INTO `tour` VALUES (9, 'Vung Tau', '1 day', 600000, 'Vung Tau is located on the peninsula of the same name, is the province of Ba Ria-Vung Tau province. Located would protrude from the mainland as a strip of land about 14km in length and width of about 6km. From here, one can look the East Sea when sunrise and sunset.<br /><br />\r\n<b>In the morning: Saigon - Vung Tau</b><br />\r\nBus tour departs leaving Ho Chi Minh City to Vung Tau, bringing tourists to the route Nguyen Thi Minh Khai, Dong Khoi, Nguyen Hue, Le Loi, Nguyen Van Linh, where there are cultural structures associated linking the economic achievements of the past and present as Saigon, etc. Independence Palace, Notre Dame Cathedral, Opera House, Ben Thanh Market, the new urban area Phu My Hung, the Phu My, broken rice breakfast at restaurant Thuan Kieu. To Vung Tau, you have fun swimming at Sea resort Thuy Van Beach (Beach). <br /><br />\r\n<b>Afternoon: Vung Tau - Saigon</b><br />\r\nBus tour to the coastal path, through the parking lot, Ocean beach (beach front). You enjoy romantic charming landscape of the coastal city of Vung Tau, with two large mountains, small mountains adjacent to the sea. Visiting the White Palace, sightseeing Hon Ba. Phong, stop at the nose Nghinh take photo, watch the Lord Jesus.<br /><br />\r\nReturn to Ho Chi Minh City University delegation visits Ba Ria Songlin stop buying seafood specialties, and the Long Thanh buy dairy products made from pure fresh milk.<br /><br />\r\nBack to Ho Chi Minh City you farewell.', 'Vung Tau', 'uploads/vung_tau.jpg?d=1336184504514', '3');
INSERT INTO `tour` VALUES (10, 'Can Tho Travel', '2 days, 1 night', 5000000, 'The Delta''s Can Tho province sprawls westwards from the eponymous provincial capital along the southern bank of the Bassac (Hau) River -- the larger of the two branches of the Mekong River. Bordered to the west by An Giang and Tien Giang provinces, to the south by Hau Giang and to the north, on the other side of the river, by Vinh Long and Dong Thap, Can Tho province is one of the most popular Delta destinations among travellers and tourists alike.<br/><br/>\r\nThe province is actually a municipality which was given provincial status when it was carved out of the larger original province (also called Can Tho) in 2004. The remainder forms the new province of Hau Giang which lies to the south. This elevated status reflects Can Tho''s importance in the region, both as a trading and transportation hub and as home to the Delta''s largest city.', 'Can Tho', 'uploads/sanvandong.jpg?d=1336187090730', '3');
INSERT INTO `tour` VALUES (11, 'Dai Nam - Binh Duong', '1 day', 1000000, 'Total area is 9 hectares. Main entrance towards Dai Nam Square is surrounded by two green dragons with length of each is 270 meters. The unique feature of Dai Nam Van Hien Wonderland is 9-hectare worship area with cultural, historical meaning and religious aspirations of Viet Nam through 4,000-year upside culture. This is an area with strong spirit including Ngu Hanh Son Mountain Range, the longest artificial mountain in Vietnam with 252m of length, recorded in Vietnam records book on September 10, 2006. Looming among Ngu Hanh Son Mountain Range is 9 storey tower called Bao Thap. Bao Giang River which is 720 meters long runs under Ngu Hanh Son Range, and winds around the temple. It is also considered as the longest artificial river in Viet Nam.\r\n\r\nDai Nam Temple was constructed on March 10, 2003 (Lunar Calendar) and opened on September 2, 2005 with an area of 5,000 square meters. Dai Nam Temple, also known as Golden Temple, is highlighted by worship statues, embossments and worshiping objects which are all inlayed with gold. The Temple was also recorded in Vietnam record book as the largest Temple in Vietnam on August 15, 2007. There are 3 worship statues at Temple''s sanctum, such as Buddha Sakyamuni, Hung King and Tran Nhan Tong King. The worship page on the left includes Tran Hung Dao Saint, Au Co Mother, 1068 lines of 54 Vietnamese ethnic groups. The worship page on the right includes Ho Chi Minh President, Nguyen Binh Khiem, as well as alter of God of Wealth - God of The Earth - God of Town - God of Merit. ', 'Dai Nam - Binh Duong', 'uploads/dai-nam-2.jpg?d=1336188462846', '3');
INSERT INTO `tour` VALUES (3, 'Ho Chi Minh', '4 days', 1000000, '<b>7:30</b> Pick you up at the corporate office started the tour to the Reunification Palace, the former U.S. headquarters located in South Vietnam. Besides, you will see Notre Dame Cathedral and Notre Dame Cathedral, both structures are unique ancient Gothic style with war museum, archive documents and photos precious about the war of Vietnam, stop shopping at Ben Thanh Market. Before returning to the corporate office to rest, eat lunch.<br /><br />\r\n \r\nAfternoon continue to visit you at Giac Lam Pagoda, the oldest temple town located on Lac Long Quan District 11. Next, you will turn to the Cholon area - Binh Tay Market - traded center of the Vietnamese community and the U.S. in Ho Chi Minh City. This was also preserved architectural value of the U.S. hundreds of years ago.', 'Ho Chi Minh', 'images/tour/sai_gon.jpg', '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `tour_booking`
-- 

CREATE TABLE `tour_booking` (
  `tour_booking_id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `date_booking` date NOT NULL,
  `username` varchar(255) NOT NULL,
  `tourID` int(11) NOT NULL,
  `transportID` int(11) NOT NULL,
  `no_ppl` int(11) NOT NULL,
  PRIMARY KEY  (`tour_booking_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

-- 
-- Dumping data for table `tour_booking`
-- 

INSERT INTO `tour_booking` VALUES (3, '2012-05-05', '2012-05-05', 'inte', 1, 1, 3);
INSERT INTO `tour_booking` VALUES (1, '2012-05-07', '2012-05-05', 'inte', 1, 1, 1);
INSERT INTO `tour_booking` VALUES (15, '2012-05-28', '2012-05-05', 'inte', 1, 1, 2);
INSERT INTO `tour_booking` VALUES (16, '2012-05-28', '2012-05-05', 'inte', 1, 1, 3);
INSERT INTO `tour_booking` VALUES (17, '0000-00-00', '0000-00-00', 'inte', 1, 2, 7);
INSERT INTO `tour_booking` VALUES (18, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 4);
INSERT INTO `tour_booking` VALUES (19, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 3);
INSERT INTO `tour_booking` VALUES (20, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 2, 3);
INSERT INTO `tour_booking` VALUES (21, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 3);
INSERT INTO `tour_booking` VALUES (22, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 2);
INSERT INTO `tour_booking` VALUES (23, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 2);
INSERT INTO `tour_booking` VALUES (24, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 2);
INSERT INTO `tour_booking` VALUES (25, '0000-00-00', '0000-00-00', 'dat.xuong', 2, 1, 2);
INSERT INTO `tour_booking` VALUES (26, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 1);
INSERT INTO `tour_booking` VALUES (27, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 3);
INSERT INTO `tour_booking` VALUES (28, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 2, 2);
INSERT INTO `tour_booking` VALUES (29, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 1);
INSERT INTO `tour_booking` VALUES (30, '0000-00-00', '0000-00-00', 'dat.xuong', 1, 1, 1);
INSERT INTO `tour_booking` VALUES (31, '0000-00-00', '0000-00-00', 'inte', 1, 1, 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `tour_occurance`
-- 

CREATE TABLE `tour_occurance` (
  `tour_occurance_id` int(11) NOT NULL auto_increment,
  `tourID` int(11) NOT NULL,
  `dayName` varchar(255) NOT NULL,
  PRIMARY KEY  (`tour_occurance_id`)
) ENGINE=MyISAM AUTO_INCREMENT=373 DEFAULT CHARSET=latin1 AUTO_INCREMENT=373 ;

-- 
-- Dumping data for table `tour_occurance`
-- 

INSERT INTO `tour_occurance` VALUES (363, 1, 'Sunday');
INSERT INTO `tour_occurance` VALUES (362, 1, 'Friday');
INSERT INTO `tour_occurance` VALUES (367, 2, 'Sunday');
INSERT INTO `tour_occurance` VALUES (366, 2, 'Tuesday');
INSERT INTO `tour_occurance` VALUES (5, 4, 'Sunday');
INSERT INTO `tour_occurance` VALUES (26, 7, 'Tuesday');
INSERT INTO `tour_occurance` VALUES (27, 7, 'Thursday');
INSERT INTO `tour_occurance` VALUES (28, 7, 'Friday');
INSERT INTO `tour_occurance` VALUES (29, 7, 'Saturnday');
INSERT INTO `tour_occurance` VALUES (30, 8, 'Wednesday');
INSERT INTO `tour_occurance` VALUES (31, 8, 'Thursday');
INSERT INTO `tour_occurance` VALUES (361, 1, 'Thursday');
INSERT INTO `tour_occurance` VALUES (360, 1, 'Monday');
INSERT INTO `tour_occurance` VALUES (47, 9, 'Sunday');
INSERT INTO `tour_occurance` VALUES (317, 10, 'Sunday');
INSERT INTO `tour_occurance` VALUES (316, 10, 'Friday');
INSERT INTO `tour_occurance` VALUES (315, 10, 'Thursday');
INSERT INTO `tour_occurance` VALUES (314, 10, 'Wednesday');
INSERT INTO `tour_occurance` VALUES (313, 10, 'Tuesday');
INSERT INTO `tour_occurance` VALUES (312, 10, 'Monday');
INSERT INTO `tour_occurance` VALUES (372, 11, 'Friday');
INSERT INTO `tour_occurance` VALUES (371, 11, 'Thursday');
INSERT INTO `tour_occurance` VALUES (370, 11, 'Wednesday');
INSERT INTO `tour_occurance` VALUES (369, 11, 'Tuesday');
INSERT INTO `tour_occurance` VALUES (368, 11, 'Monday');
INSERT INTO `tour_occurance` VALUES (336, 3, 'Saturnday');
INSERT INTO `tour_occurance` VALUES (335, 3, 'Friday');
INSERT INTO `tour_occurance` VALUES (334, 3, 'Thursday');
INSERT INTO `tour_occurance` VALUES (333, 3, 'Wednesday');
INSERT INTO `tour_occurance` VALUES (332, 3, 'Tuesday');
INSERT INTO `tour_occurance` VALUES (331, 3, 'Monday');
INSERT INTO `tour_occurance` VALUES (337, 3, 'Sunday');

-- --------------------------------------------------------

-- 
-- Table structure for table `transport`
-- 

CREATE TABLE `transport` (
  `transportID` int(11) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `description` tinytext NOT NULL,
  `price` double NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY  (`transportID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `transport`
-- 

INSERT INTO `transport` VALUES (1, 'Flight', 'We understand that a comfortable seat is very important for a pleasant flight. For your comfort while flying, and for that assured fresh feeling, we have designated the most luxurious Business Class seats. Particularly, on long-haul flights with Boeing 77', 2000000, 'images/plane.jpg');
INSERT INTO `transport` VALUES (2, 'Coach', 'Our scheduled motorcoach tours are a wonderful way to travel and learn about other cultures, foods, and ways of life, in addition to creating new friendships with fellow travelers.  From one-day excursions, to weekend getaways, to several weeks traveling ', 1000000, 'images/coach.jpg');
INSERT INTO `transport` VALUES (3, 'Train', 'Vietnam Railways System (VRS) has been the main service of domestic train. With its implementation in almost every provinces and cities in Vietnam and activity scope of 2.652 km of railway, VRS offers trips on newer trains equipped with modern air-conditi', 1500000, 'images/train.jpg');

// .po file like language pack
plupload.addI18n({
	'Select files' : 'Vælg filer',
	'Add files to the upload queue and click the start button.' : 'Tilføj filer til køen, og tryk på start.',
	'Filename' : 'Filnavn',
	'Status' : 'Status',
	'Size' : 'Størrelse',
	'Add files' : 'Tilføj filer',
	'Stop current upload' : 'Stop upload',
	'Start uploading queue' : 'Start upload',
	'Drag files here.' : 'Træk filer her.'
});
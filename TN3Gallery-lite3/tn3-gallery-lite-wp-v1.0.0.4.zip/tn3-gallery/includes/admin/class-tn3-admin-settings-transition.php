<?php

require_once (TN3::$dir.'includes/admin/class-tn3-admin-settings.php');

class TN3_Admin_Settings_Transition extends TN3_Admin_Settings
{

    var $section = "transition";	    

    function validate_options()
    {

    }

}

?>

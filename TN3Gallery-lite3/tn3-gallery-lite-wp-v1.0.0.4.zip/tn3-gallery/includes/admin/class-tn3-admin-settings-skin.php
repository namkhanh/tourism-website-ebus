<?php

require_once (TN3::$dir.'includes/admin/class-tn3-admin-settings.php');

class TN3_Admin_Settings_Skin extends TN3_Admin_Settings
{

    var $section = "skin";	    

    function admin_init()
    {
	parent::admin_init();
	wp_register_script( "tn3-admin", TN3::$url."js/tn3-admin.js" );
	wp_register_script( "tn3-log", TN3::$url."js/jquery.log.js" );
	wp_register_script( "blockUI", TN3::$url."js/jquery.blockUI.js" );
	wp_register_style( "tn3-admin", TN3::$url."css/tn3-admin.css" );
	add_action( 'admin_footer', array( &$this, 'print_tn3_js' ) );
    }
    function admin_print_styles()
    {
	wp_enqueue_style('tn3-admin');
    }
    function admin_print_scripts()
    {
	wp_enqueue_script(  'tn3-admin',
			    TN3::$url."js/tn3-admin.js",
			    array("jquery")
	);
	wp_enqueue_script('tn3-log');
	wp_enqueue_script('blockUI');
    }
    function validate_field( $name, $value, $type )
    {
	return $value;
    }
    function print_tn3_js() {
	$tn = get_option('tn3_presets_skin');
	echo "\n<script type='text/javascript'>tn3.skins={};";
	foreach($tn as $k => $v) {
	    echo "tn3.skins['".$k."']=".json_encode($v).";";
	}
	echo "</script>\n";
    }

}

?>

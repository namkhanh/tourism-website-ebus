<?php

    $tn3_presets_skin = array();

    $tn3_presets_skin['default'] = array(
	'skin'		    => array('tn3', 'tn3'),
	'width'		    => 0,
	'height'	    => 0,
	'imageClick'	    => 'next',
	'delay'		    => 7000,
	'startWithAlbums'   => false,
	'image'		    => array(
	    'crop'	    => false,
	    'idleDelay'	    => 3000,
	    'maxZoom'	    => 2,
	    'clickEvent'    => 'click'),
	'thumbnailer'	    => array(
	    'align'	    => 1,
	    'buffer'	    => 20,
	    'overMove'	    => true,
	    'mode'	    => 'thumbs',
	    'speed'	    => 8,
	    'slowdown'	    => 50,
	    'shaderColor'   => '#000000',
	    'shaderOpacity' => .5,
	    'shaderDuration'=> 200,
	    'useTitle'	    => false),
	'imageSize'	    => "/0",
	'thumbnailSize'	    => "/2"
	);
    
    
    global $tn3_plugin_defaults;
    $tn3_plugin_defaults = array( 
    'general' => array(
	'width'		    => 0,
	'height'	    => 0,
	'skin'		    => 'default',
	'imageClick'	    => 'next')
    );
    



?>
